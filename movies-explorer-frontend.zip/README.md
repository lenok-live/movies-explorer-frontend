Дипломный проект в рамках обучения в Яндекс Практикум по специальности "Веб-разработчик".

Макет - dark-2 -> https://www.figma.com/file/6FMWkB94wE7KTkcCgUXtnC/%D0%94%D0%B8%D0%BF%D0%BB%D0%BE%D0%BC%D0%BD%D1%8B%D0%B9-%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82?node-id=1%3A7266&mode=dev

https://moviesul.nomoredomainsrocks.ru/ -> Ссылка на фронтенд
https://api.moviesul.nomoredomainsicu.ru/ -> Ссылка на бэкэнд

Pull request -> https://github.com/lenok-live/movies-explorer-frontend/pull/2
