Макет - dark-2

https://moviesul.nomoredomainsrocks.ru/ -> Ссылка на фронтенд
https://api.moviesul.nomoredomainsicu.ru/ -> Ссылка на бэкэнд
